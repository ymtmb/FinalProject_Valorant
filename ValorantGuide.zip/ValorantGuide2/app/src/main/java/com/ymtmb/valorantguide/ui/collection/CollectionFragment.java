package com.ymtmb.valorantguide.ui.collection;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.ymtmb.valorantguide.MainActivity;
import com.ymtmb.valorantguide.R;

import com.ymtmb.valorantguide.OnBackPressed;
import com.ymtmb.valorantguide.ui.collection.gunbuddy.Gunbuddy;
import com.ymtmb.valorantguide.ui.collection.playercards.PlayerCards;
import com.ymtmb.valorantguide.ui.collection.sprays.Sprays;
import com.ymtmb.valorantguide.ui.collection.titles.Titles;


public class
CollectionFragment extends Fragment implements OnBackPressed {


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.fragment_collection, container, false);
        MainActivity.previousTitle = "Home";

        final Button playercards = root.findViewById(R.id.btn_playercards);
        final Button sprays = root.findViewById(R.id.btn_sprays);
        final Button gunbuddy = root.findViewById(R.id.btn_gunbuddy);
        final Button titles = root.findViewById(R.id.btn_titles);

        final NavigationView navigationView = (NavigationView) getActivity().findViewById(R.id.nav_view);

        playercards.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PlayerCards.class);
                root.getContext().startActivity(intent);
                navigationView.getMenu().getItem(4).setChecked(true);
            }
        });
        sprays.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Sprays.class);
                root.getContext().startActivity(intent);
                navigationView.getMenu().getItem(4).setChecked(true);
            }
        });

        gunbuddy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Gunbuddy.class);
                root.getContext().startActivity(intent);
                navigationView.getMenu().getItem(4).setChecked(true);
            }
        });
        titles.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Titles.class);
                root.getContext().startActivity(intent);
                navigationView.getMenu().getItem(4).setChecked(true);
            }
        });

        return root;
    }
    @Override
    public void onBackPressed() {
        getActivity().getSupportFragmentManager().popBackStack();
    }
}
