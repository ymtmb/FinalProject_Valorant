package com.ymtmb.valorantguide;

public interface OnBackPressed {
    void onBackPressed();
}
